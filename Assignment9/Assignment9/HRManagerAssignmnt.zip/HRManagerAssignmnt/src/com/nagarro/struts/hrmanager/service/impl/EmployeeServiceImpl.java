package com.nagarro.struts.hrmanager.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.nagarro.struts.hrmanager.dao.EmployeeDao;
import com.nagarro.struts.hrmanager.dao.impl.EmployeeDaoImpl;
import com.nagarro.struts.hrmanager.dto.FileUploadDetailDTO;
import com.nagarro.struts.hrmanager.exception.UserExceptionClass;
import com.nagarro.struts.hrmanager.interceptor.MyLoggingInterceptor;
import com.nagarro.struts.hrmanager.model.EmployeeDetail;
import com.nagarro.struts.hrmanager.service.EmployeeCSVReader;
import com.nagarro.struts.hrmanager.service.EmployeeService;
import com.nagarro.struts.hrmanager.utils.ConverterClass;
import com.nagarro.struts.hrmanager.utils.ReadCSVFromStream;
import com.opensymphony.xwork2.ActionSupport;

/**
 * The Class EmployeeServiceImpl implements the employeeService interface to send the data to perform
 * database operation  by the help of action class and sends the result back to action class .
 */
public class EmployeeServiceImpl implements EmployeeService {

	/**
	 * the instance of the singleton class which is used to save the overhead of
	 * defining new object.
	 */
	private static EmployeeServiceImpl instance = null;

	/**
	 * Instantiates a new employee service impl constructor so that new object
	 * cant be created.
	 */
	private EmployeeServiceImpl() {

	}

	/**
	 * Gets the single instance of EmployeeServiceImpl.It checks for the
	 * previous employee if it is not available then create a new instance
	 *
	 * @return single instance of EmployeeServiceImpl
	 */
	public static EmployeeServiceImpl getInstance() {
		if (instance == null) {
			instance = new EmployeeServiceImpl();
		}
		return instance;
	}

	/**
	 * The emp dao is the instance of the singleton class which is used to save
	 * the overhead of defining new object.
	 */
	EmployeeDao empDao = EmployeeDaoImpl.getInstance();
	
	/**
	 * The emp csvReader is the instance of the singleton class which is used to save
	 * the overhead of defining new object.
	 */
	EmployeeCSVReader empCSVReader = EmployeeCSVReaderImpl.getInstance();

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.nagarro.struts.hrmanager.service.EmployeeService#addEmployee(java.
	 * util.List)
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void addEmployee(final List empList) {

		try {
			empDao.insertDetails(empList);
		} catch (final UserExceptionClass e) {
			MyLoggingInterceptor.LOGGER.error(e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.nagarro.struts.hrmanager.service.EmployeeService#getEmployee()
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public List getEmployee() {
		List retVal = new ArrayList<>();
		try {
			retVal = empDao.getDetails();
		} catch (final UserExceptionClass e) {
			MyLoggingInterceptor.LOGGER.error(e);
		}
		return retVal;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.nagarro.struts.hrmanager.service.EmployeeService#readFile(com.nagarro
	 * .struts.hrmanager.dto.FileUploadDetailDTO)
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public String readFile(final FileUploadDetailDTO fileDetails) {
		try {

			final InputStream filecontent = new FileInputStream(fileDetails.getUsersFile());
			final byte[] fileBytes = new byte[(int) fileDetails.getUsersFile().length()];
			filecontent.read(fileBytes);
			filecontent.close();
			final File tempCSV = ReadCSVFromStream.csvStreamReader(fileBytes);

			final List empList = new ArrayList<>();
			empList.addAll(empCSVReader.readCSVFile(tempCSV));
			addEmployee(empList);

		} catch (final Exception e) {
			MyLoggingInterceptor.LOGGER.error(e);
			return ActionSupport.ERROR;
		}
		return ActionSupport.SUCCESS;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.nagarro.struts.hrmanager.service.EmployeeService#writeCSVFile(javax.
	 * servlet.http.HttpServletResponse)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public String writeCSVFile(final HttpServletResponse response) {
		response.setContentType("text/csv");

		final List<EmployeeDetail> empList = new ArrayList<EmployeeDetail>();
		empList.addAll(getEmployee());
		response.setHeader("Content-disposition", "attachment; filename=\"employee.csv\"");
		try (final PrintWriter out = response.getWriter()) {

			out.println("EmpCode|EmpName|Location|Email|DOB");
			for (final EmployeeDetail empObj : empList) {
				out.println(empObj.getEmpNumber() + "|" + empObj.getEmpName() + "|" + empObj.getEmpLocation() + "|"
						+ empObj.getEmpEmail() + "|"
						+ ConverterClass.convertDateToString(empObj.getEmpDOB(), "DD-MM-YYYY"));
			}

			out.flush();
			// out.close();

		} catch (final Exception e) {
			MyLoggingInterceptor.LOGGER.error(e);
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.nagarro.struts.hrmanager.service.EmployeeService#editEmployee(com.
	 * nagarro.struts.hrmanager.model.EmployeeDetail)
	 */
	@Override
	public String editEmployee(final EmployeeDetail empDetail) {
		String retVal = null;
		try {
			if (empDao.isDetailsUpdated(empDetail)) {
				retVal = ActionSupport.SUCCESS;
			} else {
				retVal = ActionSupport.ERROR;
			}
		} catch (final UserExceptionClass e) {
			MyLoggingInterceptor.LOGGER.error(e);
		}
		return retVal;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.nagarro.struts.hrmanager.service.EmployeeService#deleteEmployee(int)
	 */
	@Override
	public String deleteEmployee(final int empNumber) {
		String retVal = null;
		try {
			if (empDao.isDetailsDeleted(empNumber)) {
				retVal = ActionSupport.SUCCESS;
			} else {
				retVal = ActionSupport.ERROR;
			}
		} catch (final UserExceptionClass e) {
			MyLoggingInterceptor.LOGGER.error(e);
		}
		return retVal;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.nagarro.struts.hrmanager.service.EmployeeService#searchEmployee(java.
	 * lang.String)
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public List searchEmployee(final String searchString) {
		List retVal = new ArrayList<>();
		try {
			retVal = empDao.searchDetails(searchString);
		} catch (final UserExceptionClass e) {
			MyLoggingInterceptor.LOGGER.error(e);
		}
		return retVal;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.nagarro.struts.hrmanager.service.EmployeeService#orderEmployeeById()
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public List orderEmployeeById() {
		List retVal = new ArrayList<>();
		try {
			retVal = empDao.OrderById();
		} catch (final UserExceptionClass e) {
			MyLoggingInterceptor.LOGGER.error(e);
		}
		return retVal;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.nagarro.struts.hrmanager.service.EmployeeService#orderEmployeeByName(
	 * )
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public List orderEmployeeByName() {
		List retVal = new ArrayList<>();
		try {
			retVal = empDao.OrderByName();
		} catch (final UserExceptionClass e) {
			MyLoggingInterceptor.LOGGER.error(e);
		}
		return retVal;
	}

}
