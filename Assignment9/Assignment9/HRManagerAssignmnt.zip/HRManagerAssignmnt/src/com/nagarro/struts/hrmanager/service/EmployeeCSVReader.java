package com.nagarro.struts.hrmanager.service;

import java.io.File;
import java.util.List;

public interface EmployeeCSVReader {
	
	/**
	 * Read CSV file from the given directory and the path and parse it on the
	 * basis of the given delimiter in the csv file.
	 *
	 * @param file the file
	 * @return the array list after storing the results from the given csv files
	 */
	@SuppressWarnings("rawtypes")
	public List readCSVFile(final File file);
}
