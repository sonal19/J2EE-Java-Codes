package com.nagarro.struts.hrmanager.dao;

import java.util.List;

import com.nagarro.struts.hrmanager.exception.UserExceptionClass;
import com.nagarro.struts.hrmanager.model.EmployeeDetail;

/**
 * The Interface EmployeeDao.It is one the main Interface which is performing
 * database operation like inserting the values into data, deleting from the
 * database, add and updating the database.Basic CRUD operation is with database
 * is completed by help of this class
 */
public interface EmployeeDao {

	/**
	 * Insert details is used to insert the details of the employee taken from
	 * the csv file which is uploaded by the HR Manager.
	 *
	 * @param empList
	 *            the emp list is the list of the employee that is getting after
	 *            parsing the uploaded csv file
	 * @throws UserExceptionClass
	 *             the user exception class is for duplicate csv file entry.
	 */
	void insertDetails(List<EmployeeDetail> empList) throws UserExceptionClass;

	/**
	 * Gets the details of the employee data that is entered into the database
	 * and populate it from the table.
	 *
	 * @return the details of the employee to show back to the HR Manager
	 * @throws UserExceptionClass
	 *             the user exception class is if no table is present in the
	 *             database
	 */
	@SuppressWarnings("rawtypes")
	List getDetails() throws UserExceptionClass;

	/**
	 * Checks if is details updated after the edit button is pressed and after
	 * updating the employee details from database.
	 *
	 * @param empDetail
	 *            the emp detail is bringing the employee details which has to
	 *            be updated in the database
	 * @return true, if is details updated
	 * @throws UserExceptionClass
	 *             the user exception class is if no table is present in the
	 *             database
	 */
	boolean isDetailsUpdated(EmployeeDetail empDetail) throws UserExceptionClass;

	/**
	 * Checks if is details deleted after the delete button is pressed and after
	 * deleting the employee details from database.
	 *
	 * @param empNumber
	 *            the emp number which is the employee which has to be deleted
	 *            from the employeeTable
	 * @return true, if is details deleted
	 * @throws UserExceptionClass
	 *             the user exception class is if no table is present in the
	 *             database
	 */
	boolean isDetailsDeleted(int empNumber) throws UserExceptionClass;

	/**
	 * Search details provides the functionality of searching in the database
	 * and provides the searched employee name.
	 *
	 * @param searchString
	 *            the search string is the search entry which is the name of the
	 *            employee
	 * @return the list the list of the employee where the search matched with
	 *         the database data
	 * @throws UserExceptionClass
	 *             the user exception class is if no table is present in the
	 *             database
	 */
	@SuppressWarnings("rawtypes")
	List searchDetails(String searchString) throws UserExceptionClass;

	/**
	 * Order by id is used to sort the table employee id in descending order for
	 * see the employee in order.
	 *
	 * @return the list of the employee after sorting the employee
	 * @throws UserExceptionClass
	 *             the user exception class is if no table is present in the
	 *             database
	 */
	@SuppressWarnings("rawtypes")
	List OrderById() throws UserExceptionClass;

	/**
	 * Order by name is used to sort the table employee name in ascending order
	 * for see the employee in order.
	 *
	 * @return the list of the employee after sorting the employee
	 * @throws UserExceptionClass
	 *             the user exception class is if no table is present in the
	 *             database
	 */
	@SuppressWarnings("rawtypes")
	List OrderByName() throws UserExceptionClass;

}
