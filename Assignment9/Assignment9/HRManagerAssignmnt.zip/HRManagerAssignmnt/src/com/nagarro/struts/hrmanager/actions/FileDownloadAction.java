package com.nagarro.struts.hrmanager.actions;

import java.io.Serializable;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.nagarro.struts.hrmanager.service.EmployeeService;
import com.nagarro.struts.hrmanager.service.impl.EmployeeServiceImpl;
import com.opensymphony.xwork2.ActionSupport;

/**
 * The Class FileDownloadAction. It is used to download the csv file from the
 * present database.It initially writes the data in the temp CSV file and then
 * download that csv file.
 */
public class FileDownloadAction extends ActionSupport implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.opensymphony.xwork2.ActionSupport#execute()
	 */
	public String execute() {
		final HttpServletResponse response = ServletActionContext.getResponse();
		final EmployeeService empService = EmployeeServiceImpl.getInstance();
		empService.writeCSVFile(response);
		return ActionSupport.SUCCESS;

	}
}
