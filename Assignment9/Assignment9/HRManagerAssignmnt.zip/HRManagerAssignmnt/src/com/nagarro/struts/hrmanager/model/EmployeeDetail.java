package com.nagarro.struts.hrmanager.model;

import java.io.Serializable;
import java.util.Date;

// TODO: Auto-generated Javadoc
/**
 * The Class EmployeeDetail.
 */
public class EmployeeDetail implements Serializable{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The emp number is the unique employee number for identifying the employee. */
	private int empNumber;
	
	/** The emp name is the name of the employee.It can't be null. */
	private String empName;
	
	/** The emp location is the location of employee where the employee is working presently. */
	private String empLocation;
	
	/** The emp email is the email id of the employee for communicating with employee. */
	private String empEmail;
	
	/** The emp DOB is the date of birth of the employee as provided by the employee. */
	private Date empDOB;
	
	/**
	 * Gets the emp number.
	 *
	 * @return the emp number
	 */
	public int getEmpNumber() {
		return empNumber;
	}
	
	/**
	 * Sets the emp number.
	 *
	 * @param empNumber the new emp number
	 */
	public void setEmpNumber(int empNumber) {
		this.empNumber = empNumber;
	}
	
	/**
	 * Gets the emp name.
	 *
	 * @return the emp name
	 */
	public String getEmpName() {
		return empName;
	}
	
	/**
	 * Sets the emp name.
	 *
	 * @param empName the new emp name
	 */
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	
	/**
	 * Gets the emp location.
	 *
	 * @return the emp location
	 */
	public String getEmpLocation() {
		return empLocation;
	}
	
	/**
	 * Sets the emp location.
	 *
	 * @param empLocation the new emp location
	 */
	public void setEmpLocation(String empLocation) {
		this.empLocation = empLocation;
	}
	
	/**
	 * Gets the emp email.
	 *
	 * @return the emp email
	 */
	public String getEmpEmail() {
		return empEmail;
	}
	
	/**
	 * Sets the emp email.
	 *
	 * @param empEmail the new emp email
	 */
	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}
	
	/**
	 * Gets the emp DOB.
	 *
	 * @return the emp DOB
	 */
	public Date getEmpDOB() {
		return empDOB;
	}
	
	/**
	 * Sets the emp DOB.
	 *
	 * @param empDOB the new emp DOB
	 */
	public void setEmpDOB(Date empDOB) {
		this.empDOB = empDOB;
	}

}
