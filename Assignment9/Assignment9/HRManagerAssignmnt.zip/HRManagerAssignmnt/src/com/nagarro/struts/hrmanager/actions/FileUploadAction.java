package com.nagarro.struts.hrmanager.actions;

import java.io.Serializable;

import com.nagarro.struts.hrmanager.dto.FileUploadDetailDTO;
import com.nagarro.struts.hrmanager.service.EmployeeService;
import com.nagarro.struts.hrmanager.service.impl.EmployeeServiceImpl;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

/**
 * The Class FileUploadAction.It is used to upload the csv file into the
 * dtabase.After the uploading of the file it will fill the database with the
 * data that is present in the csv file.It uses a data transfer object as
 * FileUploadDetails which gives the file name, file content and file itself.
 * 
 */
@SuppressWarnings("rawtypes")
public class FileUploadAction extends ActionSupport implements ModelDriven, Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The file details is the object which is mapping the getter and setter of
	 * the data transfer object with its field and provides the value of csv
	 * file, its content and its name.It helps as modeldriven action class.
	 */
	private FileUploadDetailDTO fileDetails = new FileUploadDetailDTO();

	/**
	 * Gets the file details.
	 *
	 * @return the file details
	 */
	public FileUploadDetailDTO getFileDetails() {
		return fileDetails;
	}

	/**
	 * Sets the file details.
	 *
	 * @param fileDetails
	 *            the new file details
	 */
	public void setFileDetails(final FileUploadDetailDTO fileDetails) {
		this.fileDetails = fileDetails;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.opensymphony.xwork2.ActionSupport#execute()
	 */
	public String execute() {

		String retVal = null;
		final EmployeeService empService = EmployeeServiceImpl.getInstance();
		retVal = empService.readFile(fileDetails);

		return retVal;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.opensymphony.xwork2.ModelDriven#getModel()
	 */
	@Override
	public Object getModel() {
		return fileDetails;
	}

}
