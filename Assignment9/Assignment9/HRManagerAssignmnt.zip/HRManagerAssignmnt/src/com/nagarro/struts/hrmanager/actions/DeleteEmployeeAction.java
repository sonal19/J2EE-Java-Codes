package com.nagarro.struts.hrmanager.actions;

import java.io.Serializable;

import com.nagarro.struts.hrmanager.service.EmployeeService;
import com.nagarro.struts.hrmanager.service.impl.EmployeeServiceImpl;
import com.opensymphony.xwork2.ActionSupport;

/**
 * The Class DeleteEmployeeAction delete the employee from the database.
 * It will gets fire on delete button press.
 */
public class DeleteEmployeeAction extends ActionSupport implements Serializable {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The emp number is the unique employee number for identifying the employee. */
	private int empNumber;

	/**
	 * Gets the emp number.
	 *
	 * @return the emp number
	 */
	public int getEmpNumber() {
		return empNumber;
	}

	/**
	 * Sets the emp number.
	 *
	 * @param empNumber the new emp number
	 */
	public void setEmpNumber(final int empNumber) {
		this.empNumber = empNumber;
	}

	/* (non-Javadoc)
	 * @see com.opensymphony.xwork2.ActionSupport#execute()
	 */
	public String execute() {

		String retVal = null;
		final EmployeeService empService = EmployeeServiceImpl.getInstance();
		retVal = empService.deleteEmployee(empNumber);

		return retVal;
	}

}
