package com.nagarro.struts.hrmanager.actions;

import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;

// TODO: Auto-generated Javadoc
/**
 * The Class LoginManagerAction used to manage the login of the HR
 * Manager.manager gives it unique name and pass for login and getting access to
 * edit and delete and upload the employee details.
 */
@SuppressWarnings("serial")
public class LoginManagerAction extends ActionSupport implements SessionAware {

	/**
	 * The username is the username of the HR Manager which is provided for
	 * login purpose.
	 */
	private String username;

	/**
	 * The password is the password of the HR Manager which is provided for
	 * login purpose.
	 */
	private String password;

	/**
	 * The session map used to map the session with the current context and it
	 * will get remove when the HR manager go for logout and session got ends.
	 */
	private Map<String, Object> sessionMap;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.opensymphony.xwork2.ActionSupport#execute()
	 */
	public String execute() {
		String loggedUserName = null;
		String retVal = null;
		// check if the userName is already stored in the session
		if (sessionMap.containsKey("username")) {
			loggedUserName = (String) sessionMap.get("username");
		}
		if (loggedUserName != null && loggedUserName.equals("admin")) {
			return ActionSupport.SUCCESS; // return welcome page
		}
		// if no userName stored in the session,
		// check the entered userName and password
		if (username != null && username.equals("admin") && password != null && password.equals("pass")) {
			// add userName to the session
			sessionMap.put("username", username);
			retVal = ActionSupport.SUCCESS; // return welcome page
		} else {
			addActionError(getText("error.login"));
			retVal = ActionSupport.ERROR;
		}
		return retVal;

	}

	/**
	 * Logout is for end the session for the HR Manager after completing all
	 * work it can logout form the website.
	 *
	 * @return the string which gives the status of the function that either it
	 *         is successful or not.
	 */
	public String logout() {
		// remove userName from the session
		if (sessionMap.containsKey("username")) {
			sessionMap.remove("username");
		}
		return ActionSupport.SUCCESS;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.apache.struts2.interceptor.SessionAware#setSession(java.util.Map)
	 */
	@Override
	public void setSession(final Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}

	/**
	 * Gets the username.
	 *
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * Sets the username.
	 *
	 * @param username
	 *            the new username
	 */
	public void setUsername(final String username) {
		this.username = username;
	}

	/**
	 * Gets the password.
	 *
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Sets the password.
	 *
	 * @param password
	 *            the new password
	 */
	public void setPassword(final String password) {
		this.password = password;
	}
}
