package com.nagarro.struts.hrmanager.service.impl;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.nagarro.struts.hrmanager.interceptor.MyLoggingInterceptor;
import com.nagarro.struts.hrmanager.model.EmployeeDetail;
import com.nagarro.struts.hrmanager.service.EmployeeCSVReader;
import com.nagarro.struts.hrmanager.utils.ConverterClass;
import com.opencsv.CSVReader;

/**
 * The Class EmployeeCSVReaders reads the csv file from the directory and parse the
 * value from it using the delimiter.
 * 
 * @author ricktamkundu
 */
public class EmployeeCSVReaderImpl implements EmployeeCSVReader {
	/**
	 * the instance of the singleton class which is used to save the overhead of
	 * defining new object.
	 */
	private static EmployeeCSVReaderImpl instance = null;

	/**
	 * Instantiates a new employee CSV Reader impl constructor so that new object
	 * cant be created.
	 */
	private EmployeeCSVReaderImpl() {

	}

	/**
	 * Gets the single instance of EmployeeCSVReaderImpl.It checks for the
	 * previous employee if it is not available then create a new instance
	 *
	 * @return single instance of EmployeeCSVReaderImpl
	 */
	public static EmployeeCSVReaderImpl getInstance() {
		if (instance == null) {
			instance = new EmployeeCSVReaderImpl();
		}
		return instance;
	}
	/* (non-Javadoc)
	 * @see com.nagarro.struts.hrmanager.service.EmployeeCSVReader#readCSVFile(java.io.File)
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List readCSVFile(File file) {
		final List readList = new ArrayList();

		try (CSVReader reader = new CSVReader(new FileReader(file), '|', '"', 1);) {

			String[] line;
			while ((line = reader.readNext()) != null) {
				if (line.length > 1) {
					final EmployeeDetail empObj = new EmployeeDetail();
					empObj.setEmpNumber(Integer.parseInt(line[0]));
					empObj.setEmpName(line[1]);
					empObj.setEmpLocation(line[2]);
					empObj.setEmpEmail(line[3]);
					empObj.setEmpDOB(ConverterClass.convertStringToDate(line[4], "dd-MM-yyyy"));
					readList.add(empObj);
				}
			}
		} catch (final IOException e) {
			MyLoggingInterceptor.LOGGER.debug(e);
		}

		return readList;
	}

}
