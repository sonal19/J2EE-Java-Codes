package com.nagarro.struts.hrmanager.dto;

import java.io.File;

// TODO: Auto-generated Javadoc
/**
 * The Class FileUploadDetailDTO.
 */
public class FileUploadDetailDTO {

	/**
	 * The users file is the file that is uploaded by the user or dropped by the
	 * hr manager which contains employee details.
	 */
	private File usersFile;

	/**
	 * The users file content type is the type of the file that si uploaded by
	 * the hr manager.
	 */
	private String usersFileContentType;

	/** The users file name is the name of the uploaded file */
	private String usersFileName;

	/**
	 * Gets the users file.
	 *
	 * @return the users file
	 */
	public File getUsersFile() {
		return usersFile;
	}

	/**
	 * Sets the users file.
	 *
	 * @param usersFile
	 *            the new users file
	 */
	public void setUsersFile(File usersFile) {
		this.usersFile = usersFile;
	}

	/**
	 * Gets the users file content type.
	 *
	 * @return the users file content type
	 */
	public String getUsersFileContentType() {
		return usersFileContentType;
	}

	/**
	 * Sets the users file content type.
	 *
	 * @param usersFileContentType
	 *            the new users file content type
	 */
	public void setUsersFileContentType(String usersFileContentType) {
		this.usersFileContentType = usersFileContentType;
	}

	/**
	 * Gets the users file name.
	 *
	 * @return the users file name
	 */
	public String getUsersFileName() {
		return usersFileName;
	}

	/**
	 * Sets the users file name.
	 *
	 * @param usersFileName
	 *            the new users file name
	 */
	public void setUsersFileName(String usersFileName) {
		this.usersFileName = usersFileName;
	}

}
