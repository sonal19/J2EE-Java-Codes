package com.nagarro.struts.hrmanager.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.nagarro.struts.hrmanager.dao.EmployeeDao;
import com.nagarro.struts.hrmanager.exception.ErrorCodes;
import com.nagarro.struts.hrmanager.exception.UserExceptionClass;
import com.nagarro.struts.hrmanager.interceptor.MyLoggingInterceptor;
import com.nagarro.struts.hrmanager.model.EmployeeDetail;
import com.nagarro.struts.hrmanager.utils.ConverterClass;
import com.nagarro.struts.hrmanager.utils.DBConnector;
import com.nagarro.struts.hrmanager.utils.ParameterMapping;
import com.nagarro.struts.hrmanager.utils.ReadFromProperties;

/**
 * The Class EmployeeDaoImpl implements the employeeDao interface to perform
 * database operation by using the data provided from the service class.
 */
public class EmployeeDaoImpl implements EmployeeDao {

	/**
	 * The props is used to access the properties from the properties file and
	 * use it in the java program for easy accessing.
	 */
	public Properties props;

	/** The instance. */
	private static EmployeeDaoImpl instance = null;

	/**
	 * Instantiates a new employee dao impl.constructor so that new object cant
	 * be created.
	 */
	private EmployeeDaoImpl() {
		props = ReadFromProperties.readProperties("SQLQuery.properties");
	}

	/**
	 * Gets the single instance of EmployeeDaoImpl.It checks for the previous
	 * employee if it is not available then create a new instance
	 *
	 * @return single instance of EmployeeDaoImpl
	 */
	public static EmployeeDaoImpl getInstance() {
		if (instance == null) {
			instance = new EmployeeDaoImpl();
		}
		return instance;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.nagarro.struts.hrmanager.dao.EmployeeDao#insertDetails(java.util.
	 * List)
	 */
	@SuppressWarnings("unused")
	@Override
	public void insertDetails(final List<EmployeeDetail> empList) throws UserExceptionClass {
		final String query = props.getProperty("InsertEmpTable");
		try (final PreparedStatement ps = DBConnector.getConnection().prepareStatement(query);) {

			int update = 0;
			for (final EmployeeDetail empObj : empList) {
				ParameterMapping.mapParams(ps, empObj.getEmpNumber(), empObj.getEmpName(), empObj.getEmpLocation(),
						empObj.getEmpEmail(), empObj.getEmpDOB());
				update += ps.executeUpdate();
			}

		} catch (final Exception e) {
			MyLoggingInterceptor.LOGGER.error(e);
			throw new UserExceptionClass(ErrorCodes.DUPLICATE);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.nagarro.struts.hrmanager.dao.EmployeeDao#getDetails()
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List getDetails() throws UserExceptionClass {
		final List empList = new ArrayList<EmployeeDetail>(20);
		final String query = props.getProperty("selectEmpTable");
		try (final PreparedStatement ps = DBConnector.getConnection().prepareStatement(query);) {
			final ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				empList.add(setEmpDetails(rs));
			}

		} catch (final Exception e) {
			MyLoggingInterceptor.LOGGER.error(e);
			throw new UserExceptionClass(ErrorCodes.NOTABLE);
		}
		return empList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.nagarro.struts.hrmanager.dao.EmployeeDao#isDetailsUpdated(com.nagarro
	 * .struts.hrmanager.model.EmployeeDetail)
	 */
	@SuppressWarnings("unused")
	@Override
	public boolean isDetailsUpdated(final EmployeeDetail empDetail) throws UserExceptionClass {
		boolean retVal = false;
		final String query = props.getProperty("UpdateEmpTable");
		try (final PreparedStatement ps = DBConnector.getConnection().prepareStatement(query);) {
			MyLoggingInterceptor.LOGGER.debug(query);
			int update = 0;
			ParameterMapping.mapParams(ps, empDetail.getEmpName(), empDetail.getEmpLocation(), empDetail.getEmpEmail(),
					empDetail.getEmpDOB(), empDetail.getEmpNumber());
			update = ps.executeUpdate();
			retVal = true;

		} catch (final Exception e) {
			MyLoggingInterceptor.LOGGER.error(e);
			throw new UserExceptionClass(ErrorCodes.DUPLICATE);
		}
		return retVal;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.nagarro.struts.hrmanager.dao.EmployeeDao#isDetailsDeleted(int)
	 */
	@Override
	public boolean isDetailsDeleted(final int empNumber) throws UserExceptionClass {
		boolean retVal = false;
		final String query = props.getProperty("deleteFromEmpTable");
		try (final PreparedStatement ps = DBConnector.getConnection().prepareStatement(query);) {
			MyLoggingInterceptor.LOGGER.debug(query);
			@SuppressWarnings("unused")
			int update = 0;
			ParameterMapping.mapParams(ps, empNumber);
			update = ps.executeUpdate();
			retVal = true;
		} catch (final Exception e) {
			MyLoggingInterceptor.LOGGER.error(e);
			throw new UserExceptionClass(ErrorCodes.NOTABLE);
		}
		return retVal;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.nagarro.struts.hrmanager.dao.EmployeeDao#searchDetails(java.lang.
	 * String)
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List searchDetails(final String searchString) throws UserExceptionClass {
		final List empList = new ArrayList<EmployeeDetail>(20);
		final String query = props.getProperty("searchEmpTable");
		try (final PreparedStatement ps = DBConnector.getConnection().prepareStatement(query);) {

			ParameterMapping.mapParams(ps, "%" + searchString + "%");
			final ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				empList.add(setEmpDetails(rs));
			}

		} catch (final Exception e) {
			MyLoggingInterceptor.LOGGER.error(e);
			throw new UserExceptionClass(ErrorCodes.NOTABLE);
		}
		return empList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.nagarro.struts.hrmanager.dao.EmployeeDao#OrderById()
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List OrderById() throws UserExceptionClass {
		final List empList = new ArrayList<EmployeeDetail>(20);
		final String query = props.getProperty("OrderByEmpId");
		try (final PreparedStatement ps = DBConnector.getConnection().prepareStatement(query);) {
			final ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				empList.add(setEmpDetails(rs));
			}

		} catch (final Exception e) {
			MyLoggingInterceptor.LOGGER.error(e);
			throw new UserExceptionClass(ErrorCodes.UNKNOWNERROR);
		}
		return empList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.nagarro.struts.hrmanager.dao.EmployeeDao#OrderByName()
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List OrderByName() throws UserExceptionClass {
		final List empList = new ArrayList<EmployeeDetail>(20);
		final String query = props.getProperty("OrderByEmpName");
		try (final PreparedStatement ps = DBConnector.getConnection().prepareStatement(query);) {
			final ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				empList.add(setEmpDetails(rs));
			}
		} catch (final Exception e) {
			MyLoggingInterceptor.LOGGER.error(e);
			throw new UserExceptionClass(ErrorCodes.UNKNOWNERROR);
		}
		return empList;
	}

	/**
	 * Sets the emp details.
	 *
	 * @param rs
	 *            the rs
	 * @return the employee detail
	 * @throws NumberFormatException
	 *             the number format exception
	 * @throws SQLException
	 *             the SQL exception
	 */
	public EmployeeDetail setEmpDetails(final ResultSet rs) throws NumberFormatException, SQLException {
		final EmployeeDetail empObject = new EmployeeDetail();
		empObject.setEmpNumber(Integer.parseInt(rs.getString(1)));
		empObject.setEmpName(rs.getString(2));
		empObject.setEmpLocation(rs.getString(3));
		empObject.setEmpEmail(rs.getString(4));
		empObject.setEmpDOB(ConverterClass.convertStringToDate(rs.getString(5), "DD-MM-YYYY"));
		return empObject;
	}

}
