package com.nagarro.struts.hrmanager.interceptor;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.nagarro.struts.hrmanager.constants.Constants;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.Interceptor;

/**
 * The Class MyLoggingInterceptor is used to log the running of the application
 * with time.It gives the time when the action class is get invoked and releases
 * it back.
 */
public class MyLoggingInterceptor implements Interceptor {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The Constant LOGGER is the logger object for logging the result in the
	 * log file.
	 */
	public static final Logger LOGGER = Logger.getLogger(MyLoggingInterceptor.class.getName());

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.opensymphony.xwork2.interceptor.Interceptor#intercept(com.
	 * opensymphony.xwork2.ActionInvocation)
	 */
	public String intercept(final ActionInvocation invocation) throws Exception {

		final String className = invocation.getAction().getClass().getName();
		final long startTime = System.currentTimeMillis();
		LOGGER.debug("Before calling action: " + className);

		final String result = invocation.invoke();

		final long endTime = System.currentTimeMillis();
		LOGGER.debug("After calling action: " + className + " Time taken: " + (endTime - startTime) + " ms");

		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.opensymphony.xwork2.interceptor.Interceptor#destroy()
	 */
	public void destroy() {
		LOGGER.debug("Destroying MyLoggingInterceptor...");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.opensymphony.xwork2.interceptor.Interceptor#init()
	 */
	public void init() {
		LOGGER.debug("Initializing MyLoggingInterceptor...");
	}

	/**
	 * Initialize the log properties.
	 */
	public static void logInitialization() {
		PropertyConfigurator.configure("/resources/" + Constants.RESOURCE_PATH + "log4j.properties");
	}

}
