package com.nagarro.struts.hrmanager.actions;

import java.io.Serializable;

import com.nagarro.struts.hrmanager.model.EmployeeDetail;
import com.nagarro.struts.hrmanager.service.EmployeeService;
import com.nagarro.struts.hrmanager.service.impl.EmployeeServiceImpl;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

// TODO: Auto-generated Javadoc
/**
 * The Class EditEmployeeAction edit the employee from the database.Editing is
 * only possible with name email and Location It will gets fire on edit button
 * press.
 */
@SuppressWarnings("rawtypes")
public class EditEmployeeAction extends ActionSupport implements ModelDriven, Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The emp details is the employee pojo clas object is used to set and get
	 * the parameters of the model classes with the outside details.
	 */
	private EmployeeDetail empDetails = new EmployeeDetail();

	/**
	 * Gets the emp details.
	 *
	 * @return the emp details
	 */
	public EmployeeDetail getEmpDetails() {
		return empDetails;
	}

	/**
	 * Sets the emp details.
	 *
	 * @param empDetails
	 *            the new emp details
	 */
	public void setEmpDetails(final EmployeeDetail empDetails) {
		this.empDetails = empDetails;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.opensymphony.xwork2.ActionSupport#execute()
	 */
	public String execute() {
		String retVal = null;
		final EmployeeService empService = EmployeeServiceImpl.getInstance();
		retVal = empService.editEmployee(empDetails);

		return retVal;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.opensymphony.xwork2.ModelDriven#getModel()
	 */
	@Override
	public Object getModel() {
		return empDetails;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.opensymphony.xwork2.ActionSupport#validate()
	 */
	@Override
	public void validate() {
		if (empDetails.getEmpName() == null || empDetails.getEmpName().isEmpty()) {
			addActionError("Empty name");
		}
	}

}
