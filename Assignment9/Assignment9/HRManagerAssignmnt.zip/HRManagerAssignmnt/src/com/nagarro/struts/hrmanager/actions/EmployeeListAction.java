package com.nagarro.struts.hrmanager.actions;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nagarro.struts.hrmanager.service.EmployeeService;
import com.nagarro.struts.hrmanager.service.impl.EmployeeServiceImpl;
import com.opensymphony.xwork2.ActionSupport;

// TODO: Auto-generated Javadoc
/**
 * The Class EmployeeListAction.This action class provides so many features to
 * integrate like showing the list of the employee in the table, beside that it
 * also provides searching in table.It gives sorted table data with respect to
 * employee id and employee name as well.
 */
public class EmployeeListAction extends ActionSupport implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The search string gives the string which will be checked for searching
	 * the employee name from the database.
	 */
	private String searchString;

	/**
	 * The emp service is the instance of the singleton class which is used to
	 * save the overhead of defining new object everytime.
	 */
	EmployeeService empService = EmployeeServiceImpl.getInstance();

	/**
	 * Gets the search string.
	 *
	 * @return the search string
	 */
	public String getSearchString() {
		return searchString;
	}

	/**
	 * Sets the search string.
	 *
	 * @param searchString
	 *            the new search string
	 */
	public void setSearchString(final String searchString) {
		this.searchString = searchString;
	}

	/**
	 * The employee list.It is used to store the list of the employee and it is
	 * of employee type.
	 */
	@SuppressWarnings("rawtypes")
	private List employeeList = new ArrayList<>();

	/**
	 * Gets the employee list.
	 *
	 * @return the employee list
	 */
	@SuppressWarnings("rawtypes")
	public List getEmployeeList() {
		return employeeList;
	}

	/**
	 * Sets the employee list.
	 *
	 * @param employeeList
	 *            the new employee list
	 */
	@SuppressWarnings("rawtypes")
	public void setEmployeeList(final List employeeList) {
		this.employeeList = employeeList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.opensymphony.xwork2.ActionSupport#execute()
	 */
	@SuppressWarnings("unchecked")
	public String execute() {
		String returnVal = null;
		employeeList.addAll(empService.getEmployee());
		if (employeeList.size() > 0) {
			returnVal = ActionSupport.SUCCESS;
		} else {
			returnVal = ActionSupport.INPUT;
		}
		return returnVal;
	}

	/**
	 * Search data will search the employee data from the table and show to the
	 * user according to the string entered by the user.
	 *
	 * @return the string which gives the status of the function that either it
	 *         is successful or not
	 */
	@SuppressWarnings("unchecked")
	public String searchData() {
		String returnVal = null;
		employeeList.addAll(empService.searchEmployee(searchString));
		if (employeeList.size() > 0) {
			returnVal = ActionSupport.SUCCESS;
		} else {
			returnVal = ActionSupport.INPUT;
		}
		return returnVal;
	}

	/**
	 * Order by emp id.It will order the table with respect to employee id on
	 * descending order.
	 *
	 * @return the string which gives the status of the function that either it
	 *         is successful or not
	 */
	@SuppressWarnings("unchecked")
	public String orderByEmpId() {
		String returnVal = null;
		employeeList.addAll(empService.orderEmployeeById());
		if (employeeList.size() > 0) {
			returnVal = ActionSupport.SUCCESS;
		} else {
			returnVal = ActionSupport.INPUT;
		}
		return returnVal;
	}

	/**
	 * Order by emp name.It will order the table with respect to employee name
	 * on ascending order.
	 *
	 * @return the string which gives the status of the function that either it
	 *         is successful or not
	 */
	@SuppressWarnings("unchecked")
	public String orderByEmpName() {
		String returnVal = null;
		employeeList.addAll(empService.orderEmployeeByName());
		if (employeeList.size() > 0) {
			returnVal = ActionSupport.SUCCESS;
		} else {
			returnVal = ActionSupport.INPUT;
		}
		return returnVal;
	}

}
