package com.nagarro.struts.hrmanager.constants;

// TODO: Auto-generated Javadoc
/**
 * The Class Constants to store the constant values like queries, connection
 * string, Drivers etc.
 * 
 * @author ricktamkundu
 */
public class Constants {

	/*
	 * Name of fields that should be used in the string given by user for input
	 * and output
	 */

	/**
	 * The Constant RESOURCE_PATH for accessing the properties file from the
	 * resources.
	 */
	public static final String RESOURCE_PATH = "com/nagarro/struts/hrmanager/resources/";

}
