package com.nagarro.struts.hrmanager.interceptor;

import java.util.Map;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.Interceptor;

/**
 * The Class AuthenticationInterceptor will run everytime and check for the
 * session and if the session does not exist then it will automatically get
 * redirected to the session out.
 */
public class AuthenticationInterceptor implements Interceptor {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.opensymphony.xwork2.interceptor.Interceptor#intercept(com.
	 * opensymphony.xwork2.ActionInvocation)
	 */
	@Override
	public String intercept(final ActionInvocation invocation) throws Exception {

		final Map<String, Object> session = invocation.getInvocationContext().getSession();
		MyLoggingInterceptor.LOGGER.debug("Authenticating.....");
		final String userName = (String) session.get("username");
		if (userName == null) {
			return Action.NONE;
		}
		return invocation.invoke();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.opensymphony.xwork2.interceptor.Interceptor#destroy()
	 */
	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.opensymphony.xwork2.interceptor.Interceptor#init()
	 */
	@Override
	public void init() {
		// TODO Auto-generated method stub

	}

}
