package com.nagarro.struts.hrmanager.service;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.nagarro.struts.hrmanager.dto.FileUploadDetailDTO;
import com.nagarro.struts.hrmanager.model.EmployeeDetail;

/**
 * The Interface EmployeeService.It is one the main Interface which is
 * performing service for database operation like inserting the values into
 * data, deleting from the database, add and updating the database.Basic CRUD
 * operation is with database is completed by help of this class and it helps in
 * some other database handling rather than connecting dao and action classes
 */
public interface EmployeeService {

	/**
	 * Adds the employee is used to insert the details of the employee taken
	 * from the csv file which is uploaded by the HR Manager.
	 *
	 * @param empList
	 *            the emp list is the list of the employee that is getting after
	 *            parsing the uploaded csv file
	 */
	@SuppressWarnings("rawtypes")
	public void addEmployee(List empList);

	/**
	 * Gets the employee gets the details of the employee data that is entered
	 * into the database and populate it from the table.
	 *
	 * @return the details of the employee to show back to the HR Manager
	 */
	@SuppressWarnings("rawtypes")
	public List getEmployee();

	/**
	 * Read file is used to store the data from the uploaded file to the
	 * database by using temporary file and bye stream.
	 *
	 * @param fileDetails
	 *            the file details is the object of the dto for mapping the file
	 *            name, content with it.
	 * @return the string which gives the status of the function that either it
	 *         is successful or not
	 */
	public String readFile(FileUploadDetailDTO fileDetails);

	/**
	 * Write CSV file is used to write the csv file into the stream and download
	 * the stream as csv file.It gets the details from the database
	 *
	 * @param response
	 *            the response is the http response for downloading the file.
	 * @return the string which gives the status of the function that either it
	 *         is successful or not
	 */
	public String writeCSVFile(HttpServletResponse response);

	/**
	 * Edits the employee after the edit button is pressed and after updating
	 * the employee details from database.
	 *
	 * @param empDetail
	 *            the emp detail is bringing the employee details which has to
	 *            be updated in the database
	 * 
	 * @return the string after the edit button is pressed and after updating
	 *         the employee details from database.
	 */
	public String editEmployee(EmployeeDetail empDetail);

	/**
	 * Delete employee after the delete button is pressed and after deleting the
	 * employee details from database.
	 *
	 * @param empNumber
	 *            the emp number which is the employee which has to be deleted
	 *            from the employeeTable
	 * @return the string after the edit button is pressed and after updating
	 *         the employee details from database.
	 */
	public String deleteEmployee(int empNumber);

	/**
	 * Search details provides the functionality of searching in the database
	 * and provides the searched employee name.
	 *
	 * @param searchString
	 *            the search string is the search entry which is the name of the
	 *            employee
	 * @return the list of the employee that has to be shown HR Manager
	 */
	@SuppressWarnings("rawtypes")
	public List searchEmployee(String searchString);

	/**
	 * Order by id is used to sort the table employee id in descending order for
	 * see the employee in order.
	 *
	 * @return the list of the employee after sorting the employee
	 */
	@SuppressWarnings("rawtypes")
	public List orderEmployeeById();

	/**
	 * Order by name is used to sort the table employee name in ascending order
	 * for see the employee in order.
	 *
	 * @return the list of the employee after sorting the employee
	 */
	@SuppressWarnings("rawtypes")
	public List orderEmployeeByName();

}
